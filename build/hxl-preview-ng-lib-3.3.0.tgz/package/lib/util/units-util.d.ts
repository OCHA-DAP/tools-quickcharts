export declare class UnitsUtil {
    static computeBiteUnit(value: number): string;
    static transform(value: number, format: string, unit: string): string;
    private static computeValueBasedOnUnit;
}
