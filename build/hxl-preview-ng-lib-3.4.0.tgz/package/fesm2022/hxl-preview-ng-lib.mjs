import * as i0 from '@angular/core';
import { Component, Input, ViewChild, Injectable, NgModule } from '@angular/core';
import * as i1 from 'ngx-bootstrap/modal';
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { AsyncSubject, forkJoin, of, throwError, Observable, merge } from 'rxjs';
import { flatMap, map, catchError, mergeMap, toArray, publishLast, refCount } from 'rxjs/operators';
import * as i2 from '@angular/common/http';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { ComponentLoaderFactory } from 'ngx-bootstrap/component-loader';
import { PositioningService } from 'ngx-bootstrap/positioning';

class SimpleModalComponent {
    constructor() { }
    ngOnInit() {
    }
    show() {
        this.staticModal.show();
    }
    hide() {
        this.staticModal.hide();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: SimpleModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.5", type: SimpleModalComponent, isStandalone: false, selector: "hxl-simple-modal", inputs: { title: "title" }, viewQueries: [{ propertyName: "staticModal", first: true, predicate: ["staticModal"], descendants: true }], ngImport: i0, template: "<div class=\"modal fade in\" bsModal #staticModal=\"bs-modal\" [config]=\"{backdrop: 'static'}\"\n     tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"mySmallModalLabel\" aria-hidden=\"true\">\n  <div class=\"modal-dialog modal-sm\" style=\"width: 500px;\">\n    <div class=\"modal-content\">\n      <div class=\"modal-header\">\n        <h4 class=\"modal-title pull-left\">{{title}}</h4>\n        <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"staticModal.hide()\">\n          <span aria-hidden=\"true\">&times;</span>\n        </button>\n      </div>\n      <div class=\"modal-body\" style=\"text-align: left;\">\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [".modal-content{border-radius:6px}.modal-header{background-color:#fff;border-radius:6px}::ng-deep bs-modal-backdrop.modal-backdrop.fade{opacity:.5}\n"], dependencies: [{ kind: "directive", type: i1.ModalDirective, selector: "[bsModal]", inputs: ["config", "closeInterceptor"], outputs: ["onShow", "onShown", "onHide", "onHidden"], exportAs: ["bs-modal"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: SimpleModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxl-simple-modal', standalone: false, template: "<div class=\"modal fade in\" bsModal #staticModal=\"bs-modal\" [config]=\"{backdrop: 'static'}\"\n     tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"mySmallModalLabel\" aria-hidden=\"true\">\n  <div class=\"modal-dialog modal-sm\" style=\"width: 500px;\">\n    <div class=\"modal-content\">\n      <div class=\"modal-header\">\n        <h4 class=\"modal-title pull-left\">{{title}}</h4>\n        <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"staticModal.hide()\">\n          <span aria-hidden=\"true\">&times;</span>\n        </button>\n      </div>\n      <div class=\"modal-body\" style=\"text-align: left;\">\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [".modal-content{border-radius:6px}.modal-header{background-color:#fff;border-radius:6px}::ng-deep bs-modal-backdrop.modal-backdrop.fade{opacity:.5}\n"] }]
        }], ctorParameters: () => [], propDecorators: { title: [{
                type: Input
            }], staticModal: [{
                type: ViewChild,
                args: ['staticModal']
            }] } });

/**
 * Mostly based on https://github.com/HXLStandard/libhxl-js/blob/master/hxl.js
 */
class Pattern {
    static { this.existingPatternMap = {}; }
    static { this.matchingResultsMap = {}; }
    static matchPatternToColumn(hxlPattern, hxlColumn) {
        if (hxlPattern && hxlPattern.trim() && hxlColumn && hxlColumn.trim()) {
            hxlPattern = hxlPattern.trim();
            hxlColumn = hxlColumn.trim();
            const key = `${hxlPattern}-${hxlColumn}`;
            let result = Pattern.matchingResultsMap[key];
            if (!result && result !== false) {
                const pattern = Pattern.parse(hxlPattern);
                result = pattern.matchHxlColumn(hxlColumn);
                Pattern.matchingResultsMap[key] = result;
                // console.log(`Match computed for ${key} -> ${result}`);
            }
            else {
                // console.log(`Match result found in cache for ${key} -> ${result}`);
            }
            return result;
        }
        else if (!hxlColumn || !hxlColumn.trim()) {
            return false;
        }
        throw new Error('hxlPattern should not be empty');
    }
    static parse(hxlPattern) {
        hxlPattern = hxlPattern.trim();
        let pattern = Pattern.existingPatternMap[hxlPattern];
        if (!pattern) {
            pattern = new Pattern(hxlPattern);
            Pattern.existingPatternMap[hxlPattern] = pattern;
        }
        return pattern;
    }
    /**
     * Based on https://github.com/HXLStandard/libhxl-js/blob/master/hxl.js hxl.classes.Pattern.parse()
     * @param hxlPattern
     */
    constructor(hxlPattern) {
        this.includeAttributes = new Set();
        this.excludeAttributes = new Set();
        const result = String(hxlPattern).match(/^\s*#?([A-Za-z][A-Za-z0-9_]*)((?:\s*[+-][A-Za-z][A-Za-z0-9_]*)*)\s*$/);
        if (result) {
            const attributeSpecs = result[2].split(/\s*([+-])/).filter(function (item) { return item; });
            for (let i = 0; i < attributeSpecs.length; i += 2) {
                if (attributeSpecs[i] === '+') {
                    this.includeAttributes.add(attributeSpecs[i + 1]);
                }
                else {
                    this.excludeAttributes.add(attributeSpecs[i + 1]);
                }
            }
            this.tag = '#' + result[1];
        }
    }
    matchAttributes(colAttributes) {
        let attributesMatch = true;
        this.includeAttributes.forEach(inclAttribute => {
            if (!colAttributes.has(inclAttribute)) {
                attributesMatch = false;
            }
        });
        if (attributesMatch) {
            this.excludeAttributes.forEach(exclAttribute => {
                if (colAttributes.has(exclAttribute)) {
                    attributesMatch = false;
                }
            });
        }
        return attributesMatch;
    }
    matchHxlColumn(hxlColumn) {
        /**
         * Based on https://github.com/HXLStandard/libhxl-js/blob/master/hxl.js hxl.classes.Column.parse()
         */
        const result = hxlColumn.match(/^\s*(#[A-Za-z][A-Za-z0-9_]*)((\s*\+[A-Za-z][A-Za-z0-9_]*)*)?\s*$/);
        let colAttributes = new Set();
        if (result) {
            if (result[2]) {
                // filter out empty values
                colAttributes = new Set(result[2].split(/\s*\+/).filter(function (attribute) { return attribute; }));
            }
            let columnTag = result[1];
            if (columnTag === this.tag && this.matchAttributes(colAttributes)) {
                return true;
            }
        }
        else {
            console.log('hxlColumn is empty');
        }
        return false;
    }
}

class Ingredient {
    constructor(aggregateColumn, valueColumn, aggregateFunction, dateColumn, comparisonValueColumn, comparisonOperator, filters, title, description) {
        this.aggregateColumn = aggregateColumn;
        this.valueColumn = valueColumn;
        this.aggregateFunction = aggregateFunction;
        this.dateColumn = dateColumn;
        this.comparisonValueColumn = comparisonValueColumn;
        this.comparisonOperator = comparisonOperator;
        this.filters = filters;
        this.title = title;
        this.description = description;
    }
}
class BiteFilters {
    constructor(filterWith, filterWithout) {
        this.filterWith = filterWith;
        this.filterWithout = filterWithout;
    }
    static mergeBiteFilters(biteFilters1, biteFilters2) {
        let newFilterWith = null;
        let newFilterWithout = null;
        if (biteFilters1) {
            newFilterWith = biteFilters1.filterWith || [];
            newFilterWithout = biteFilters1.filterWithout || [];
        }
        else {
            newFilterWith = [];
            newFilterWithout = [];
        }
        if (biteFilters2) {
            if (biteFilters2.filterWith) {
                newFilterWith = newFilterWith.concat(biteFilters2.filterWith);
            }
            if (biteFilters2.filterWithout) {
                newFilterWithout = newFilterWithout.concat(biteFilters2.filterWithout);
            }
        }
        return new BiteFilters(newFilterWith, newFilterWithout);
    }
}

class Bite {
    static type() {
        return 'bite';
    }
    constructor(ingredient, recipeOptions) {
        this.tempShowSaveCancelButtons = false;
        this.ingredient = ingredient;
        this.recipeOptions = recipeOptions;
        this.type = this.constructor.type();
        this.errorMsg = null;
    }
}
class ComputedProperties {
    constructor() {
        this.explainedFiltersMap = {};
    }
}
class UIProperties {
    constructor() {
        this.numberDecimals = 1;
    }
}
/**
 * Data coming from the hxl proxy (processed maybe for showing in the charts)
 */
class DataProperties {
}

class ChartBite extends Bite {
    static { this.colorPattern = ['#1ebfb3', '#0077ce', '#f2645a', '#9C27B0']; }
    static { this.SORT_DESC = 'DESC'; }
    static { this.SORT_ASC = 'ASC'; }
    static type() {
        return 'chart';
    }
    constructor(ingredient, recipeOptions) {
        super(ingredient, recipeOptions);
        this.computedProperties = new ChartComputedProperties();
        this.uiProperties = new ChartUIProperties();
        this.dataProperties = new ChartDataProperties();
        this.displayCategory = 'Charts';
    }
}
class ChartUIProperties extends UIProperties {
    constructor() {
        super(...arguments);
        this.swapAxis = true;
        this.showGrid = false;
        this.color = null;
        this.sortingByValue1 = ChartBite.SORT_DESC;
        this.sortingByCategory1 = null;
    }
}
class ChartComputedProperties extends ComputedProperties {
    constructor() {
        super(...arguments);
        this.pieChart = false;
    }
}
class ChartDataProperties extends DataProperties {
}

class KeyFigureBite extends Bite {
    static type() {
        return 'key figure';
    }
    constructor(ingredient) {
        super(ingredient);
        this.computedProperties = new KeyFigureComputedProperties();
        this.uiProperties = new KeyFigureUIProperties();
        this.dataProperties = new KeyFigureDataProperties();
        // Commented bc we do the same in BiteLogic.populateDataTitleWithHxlProxyInfo()
        // this.dataTitle = ingredient.valueColumn;
        this.displayCategory = 'Key Figures';
        // this.unit = null;
    }
}
class KeyFigureUIProperties extends UIProperties {
}
class KeyFigureComputedProperties extends ComputedProperties {
}
class KeyFigureDataProperties extends DataProperties {
}

class ComparisonChartBite extends ChartBite {
    static type() {
        return 'comparison-chart';
    }
    constructor(ingredient) {
        super(ingredient);
        this.dataProperties = new ComparisonChartDataProperties();
        this.uiProperties = new ComparisonChartUIProperties();
        this.computedProperties = new ComparisonChartComputedProperties();
    }
}
class ComparisonChartDataProperties extends ChartDataProperties {
}
class ComparisonChartComputedProperties extends ChartComputedProperties {
}
class ComparisonChartUIProperties extends ChartUIProperties {
    constructor() {
        super();
        this.stackChart = false;
        this.comparisonColor = null;
        this.sortingByValue2 = null;
        this.sortingByValue1 = null;
    }
}

class BiteLogic {
    constructor(bite) {
        this.bite = bite;
        this.tagToIndexMap = {};
    }
    /**
     * Generally used before saving the bite. We don't want the values to be saved as well.
     * The bites should have fresh data loaded from the data source each time.
     *
     */
    unpopulateBite() {
        this.bite.dataProperties = this.initDataProperties();
        this.bite.tempShowSaveCancelButtons = false;
        this.bite.errorMsg = null;
        return this;
    }
    resetBite() {
        this.bite.dataProperties = this.initDataProperties();
        this.bite.uiProperties = this.initUIProperties();
        this.bite.computedProperties = this.initComputedProperties();
        this.bite.tempShowSaveCancelButtons = false;
        return this;
    }
    populateDataTitleWithHxlProxyInfo() {
        if (!this.bite.computedProperties.dataTitle) {
            this.bite.computedProperties.dataTitle = this.bite.ingredient.valueColumn;
        }
        return this;
    }
    findHxlTagIndex(hxlTag, hxlData) {
        if (hxlData && hxlData.length > 2) {
            for (let i = 0; i < hxlData[1].length; i++) {
                const currentTag = hxlData[1][i];
                if (Pattern.matchPatternToColumn(hxlTag, currentTag)) {
                    return i;
                }
            }
        }
        return -1;
    }
    getBite() {
        return this.bite;
    }
    populateHashCode() {
        this.bite.hashCode = this.strListHash(this.buildImportantPropertiesList());
        return this;
    }
    buildImportantPropertiesList() {
        const importantProperties = [];
        importantProperties.push(this.bite.ingredient.title, this.bite.type);
        importantProperties.push(this.bite.ingredient.valueColumn, this.bite.ingredient.aggregateColumn);
        return importantProperties;
    }
    strHash(theString, startHash) {
        let i, chr, len;
        let hash = startHash ? startHash : 0;
        if (!theString || theString.length === 0) {
            return hash;
        }
        for (i = 0, len = theString.length; i < len; i++) {
            chr = theString.charCodeAt(i);
            /* tslint:disable */
            hash = ((hash << 5) - hash) + chr;
            hash |= 0; // Convert to 32bit integer
            /* tslint:enable */
        }
        return hash;
    }
    strListHash(strList) {
        let hash = 0;
        if (strList) {
            for (let i = 0; i < strList.length; i++) {
                const curStr = strList[i];
                hash = this.strHash(curStr, hash);
            }
        }
        return hash;
    }
    populateWithTitle(columnNames, hxlTags) {
        hxlTags.forEach((v, idx) => this.tagToIndexMap[v] = idx);
        const valueColumn = columnNames[this.tagToIndexMap[this.bite.ingredient.valueColumn]];
        const hxlValueColumn = hxlTags[this.tagToIndexMap[this.bite.ingredient.valueColumn]];
        const groupColumn = columnNames[this.tagToIndexMap[this.bite.ingredient.aggregateColumn]];
        if (!this.bite.ingredient.title) {
            let aggFunction = null;
            switch (this.bite.ingredient.aggregateFunction) {
                case 'count':
                    aggFunction = 'Row Count';
                    break;
                case 'distinct-count':
                    aggFunction = 'Unique Values in';
                    break;
                case 'sum':
                    aggFunction = 'Sum of';
                    break;
                case 'average':
                    aggFunction = 'Average of';
                    break;
                default:
                    aggFunction = 'Sum of';
                    break;
            }
            let title = aggFunction;
            if (valueColumn && valueColumn.trim().length > 0) {
                title += ' ' + valueColumn;
            }
            else if (hxlValueColumn && hxlValueColumn.trim().length > 0) {
                title += ' ' + hxlValueColumn;
            }
            if (groupColumn && groupColumn.trim().length > 0) {
                title += ' by ' + groupColumn;
            }
            this.bite.computedProperties.title = title;
        }
        this.bite.computedProperties.dataTitle = (valueColumn && valueColumn.length > 0) ? valueColumn : hxlValueColumn;
        return this;
    }
    populateDefaultFilters() {
        return this;
    }
    hasFilters() {
        const filters = this.filters;
        if (filters) {
            const filterWith = filters.filterWith;
            const filterWithout = filters.filterWithout;
            if (filterWith && filterWith.length > 0) {
                return true;
            }
            else if (filterWithout && filterWithout.length > 0) {
                return true;
            }
        }
        return false;
    }
    usesDateColumn() {
        // if (this.bite.ingredient.dateColumn) {
        //   return true;
        // }
        return false;
    }
    initColorsIfNeeded(internalColorPattern) {
        if (!this.uiProperties.internalColorPattern) {
            this.uiProperties.internalColorPattern = internalColorPattern;
        }
    }
    findComputedFilters() {
        return null;
    }
    get sortingByValue1Label() {
        return null;
    }
    get sortingByValue2Label() {
        return null;
    }
    get sortingByCategory1Label() {
        return null;
    }
    get dataProperties() {
        return this.bite.dataProperties;
    }
    get uiProperties() {
        return this.bite.uiProperties;
    }
    get recipeOptions() {
        return this.bite.recipeOptions;
    }
    get computedProperties() {
        return this.bite.computedProperties;
    }
    get dateColumn() {
        return this.bite.ingredient.dateColumn;
    }
    get valueColumns() {
        return [this.bite.ingredient.valueColumn];
    }
    get title() {
        const defaultTitle = this.bite.ingredient.title || this.bite.computedProperties.title;
        const title = (this.bite.uiProperties.title == null ? defaultTitle : this.bite.uiProperties.title);
        return title;
    }
    get description() {
        const defaultDescription = this.bite.ingredient.description;
        const description = this.bite.uiProperties.description == null ? defaultDescription : this.bite.uiProperties.description;
        return description;
    }
    get descriptionLength() {
        return this.description ? this.description.length : 0;
    }
    get dataTitle() {
        const defaultDataTitle = this.bite.computedProperties.dataTitle;
        const dataTitle = this.bite.uiProperties.dataTitle == null ? defaultDataTitle : this.bite.uiProperties.dataTitle;
        return dataTitle;
    }
    get internalColorPattern() {
        return this.uiProperties.internalColorPattern;
    }
    get tempShowSaveCancelButtons() {
        this.bite.tempShowSaveCancelButtons = this.bite.tempShowSaveCancelButtons || false;
        return this.bite.tempShowSaveCancelButtons;
    }
    set tempShowSaveCancelButtons(tempShowSaveCancelButtons) {
        this.bite.tempShowSaveCancelButtons = tempShowSaveCancelButtons;
    }
    get filters() {
        const computedFilters = this.computedProperties.explainedFiltersMap ?
            Object.values(this.computedProperties.explainedFiltersMap) : [];
        const mergedComputedFilter = computedFilters.reduce((acc, current) => BiteFilters.mergeBiteFilters(acc, current), new BiteFilters([], []));
        return BiteFilters.mergeBiteFilters(mergedComputedFilter, this.bite.ingredient.filters);
    }
}
var ColorUsage;
(function (ColorUsage) {
    ColorUsage[ColorUsage["NONE"] = 0] = "NONE";
    ColorUsage[ColorUsage["ONE"] = 1] = "ONE";
    ColorUsage[ColorUsage["MANY"] = 2] = "MANY";
})(ColorUsage || (ColorUsage = {}));

class ChartBiteLogic extends BiteLogic {
    constructor(bite) {
        super(bite);
        this.bite = bite;
    }
    populateWithHxlProxyInfo(hxlData, tagToTitleMap) {
        super.populateDataTitleWithHxlProxyInfo();
        const valColIndex = this.findHxlTagIndex(this.bite.ingredient.valueColumn, hxlData);
        const aggColIndex = this.findHxlTagIndex(this.bite.ingredient.aggregateColumn, hxlData);
        const dataProperties = this.bite.dataProperties;
        const computedProperties = this.bite.computedProperties;
        if (aggColIndex >= 0 && valColIndex >= 0) {
            dataProperties.values = [computedProperties.dataTitle];
            dataProperties.categories = [];
            for (let i = 2; i < hxlData.length; i++) {
                dataProperties.values.push(hxlData[i][valColIndex]);
                dataProperties.categories.push(hxlData[i][aggColIndex]);
            }
            computedProperties.pieChart = !(dataProperties.values.length > 5);
        }
        else {
            throw new Error(`${this.bite.ingredient.valueColumn} or ${this.bite.ingredient.aggregateColumn}`
                + 'not found in hxl proxy response');
        }
        return this;
    }
    initUIProperties() {
        return new ChartUIProperties();
    }
    initComputedProperties() {
        return new ChartComputedProperties();
    }
    initDataProperties() {
        return new ChartDataProperties();
    }
    colorUsage() {
        if (this.pieChart) {
            return ColorUsage.NONE;
        }
        return ColorUsage.ONE;
    }
    initColorsIfNeeded(colorPattern) {
        super.initColorsIfNeeded(colorPattern);
        if (!this.uiProperties.color) {
            this.uiProperties.color = colorPattern[0];
        }
    }
    isGroupedByDateColumn() {
        if (this.bite.ingredient.aggregateColumn) {
            return this.bite.ingredient.aggregateColumn.indexOf('#date') >= 0;
        }
        return false;
    }
    hasData() {
        // for pie charts we need at least 2 values (plus the title)
        if (this.values != null && this.values.length >= 3) {
            return true;
        }
        return false;
    }
    get dataProperties() {
        return this.bite.dataProperties;
    }
    get uiProperties() {
        return this.bite.uiProperties;
    }
    get computedProperties() {
        return this.bite.computedProperties;
    }
    get pieChart() {
        const computedProperties = this.computedProperties;
        const pieChart = this.forcedChartType ?
            this.forcedChartType === 'pie' : computedProperties.pieChart;
        return pieChart;
    }
    get forcedChartType() {
        if (this.recipeOptions) {
            return this.recipeOptions.forcedChartType;
        }
        return undefined;
    }
    get swapAxis() {
        return this.uiProperties.swapAxis;
    }
    get showGrid() {
        return this.uiProperties.showGrid;
    }
    get color() {
        return this.uiProperties.color;
    }
    get sortingByValue1() {
        return this.uiProperties.sortingByValue1;
    }
    set sortingByValue1(sortingByValue1) {
        if (sortingByValue1) {
            this.uiProperties.sortingByCategory1 = null;
        }
        this.uiProperties.sortingByValue1 = sortingByValue1;
    }
    get sortingByCategory1() {
        if (this.sortingByValue1) {
            return null;
        }
        return this.uiProperties.sortingByCategory1;
    }
    set sortingByCategory1(sortingByCategory1) {
        if (sortingByCategory1) {
            this.uiProperties.sortingByValue1 = null;
        }
        this.uiProperties.sortingByCategory1 = sortingByCategory1;
    }
    get limit() {
        return this.uiProperties.limit;
    }
    get actualNumOfUsedValues() {
        if (this.values.length > MAX_LIMIT_VALUE && (!this.limit || this.limit > MAX_LIMIT_VALUE)) {
            this.uiProperties.limit = MAX_LIMIT_VALUE;
            return MAX_LIMIT_VALUE;
        }
        if (this.limit && this.limit < this.values.length) {
            return this.limit;
        }
        return this.values.length;
    }
    get categories() {
        return this.dataProperties.categories;
    }
    get values() {
        return this.dataProperties.values;
    }
    get sortingByValue1Label() {
        return 'Sort by values';
    }
    get sortingByValue2Label() {
        return null;
    }
    get sortingByCategory1Label() {
        return 'Sort by category';
    }
}
const MAX_LIMIT_VALUE = 100;

class ComparisonChartBiteLogic extends ChartBiteLogic {
    constructor(bite) {
        super(bite);
        this.bite = bite;
    }
    buildImportantPropertiesList() {
        const importantProperties = super.buildImportantPropertiesList();
        importantProperties.push(this.bite.ingredient.comparisonValueColumn, this.bite.ingredient.comparisonOperator);
        return importantProperties;
    }
    populateWithHxlProxyInfo(hxlData, tagToTitleMap) {
        super.populateWithHxlProxyInfo(hxlData, tagToTitleMap);
        this.computedProperties.pieChart = false;
        const valColIndex = this.findHxlTagIndex(this.bite.ingredient.valueColumn, hxlData);
        const compColIndex = this.findHxlTagIndex(this.bite.ingredient.comparisonValueColumn, hxlData);
        if (compColIndex >= 0) {
            this.dataProperties.comparisonValues = [this.bite.ingredient.comparisonValueColumn];
            for (let i = 2; i < hxlData.length; i++) {
                const computedValue = hxlData[i][compColIndex];
                // If we have more than 1 row of data
                // if (hxlData.length > 3) {
                //   computedValue = computedValue - hxlData[i][valColIndex];
                // }
                this.dataProperties.comparisonValues.push(computedValue);
            }
        }
        else {
            throw new Error(`${this.bite.ingredient.comparisonValueColumn}` + ' not found in hxl proxy response');
        }
        return this;
    }
    populateDataTitleWithHxlProxyInfo() {
        super.populateDataTitleWithHxlProxyInfo();
        const computedProperties = this.bite.computedProperties;
        if (!computedProperties.comparisonDataTitle) {
            const ingredient = this.bite.ingredient;
            computedProperties.comparisonDataTitle = ingredient.comparisonValueColumn;
        }
        return this;
    }
    populateWithTitle(columnNames, hxlTags) {
        super.populateWithTitle(columnNames, hxlTags);
        const computedProperties = this.bite.computedProperties;
        const availableTags = {};
        hxlTags.forEach((v, idx) => availableTags[v] = idx);
        const ingrValColumn = this.bite.ingredient.comparisonValueColumn;
        const valueColumn = columnNames[availableTags[ingrValColumn]];
        const hxlValueColumn = hxlTags[availableTags[ingrValColumn]];
        computedProperties.comparisonDataTitle = (valueColumn && valueColumn.length > 0) ? valueColumn : hxlValueColumn;
        return this;
    }
    initUIProperties() {
        return new ComparisonChartUIProperties();
    }
    initDataProperties() {
        return new ComparisonChartDataProperties();
    }
    colorUsage() {
        return ColorUsage.MANY;
    }
    initColorsIfNeeded(colorPattern) {
        super.initColorsIfNeeded(colorPattern);
        if (!this.uiProperties.comparisonColor) {
            this.uiProperties.comparisonColor = colorPattern[1];
        }
    }
    hasData() {
        // we need at least 1 datapoint to show a comparison chart
        if (this.values != null && this.values.length >= 2) {
            return true;
        }
        return false;
    }
    get dataProperties() {
        return this.bite.dataProperties;
    }
    get uiProperties() {
        return this.bite.uiProperties;
    }
    get valueColumns() {
        return [
            this.bite.ingredient.valueColumn,
            this.bite.ingredient.comparisonValueColumn
        ];
    }
    get comparisonValues() {
        return this.dataProperties.comparisonValues;
    }
    get stackChart() {
        return this.uiProperties.stackChart;
    }
    get comparisonDataTitle() {
        const uiProperties = this.bite.uiProperties;
        const computedProperties = this.bite.computedProperties;
        const defaultDataTitle = computedProperties.comparisonDataTitle;
        const comparisonDataTitle = uiProperties.comparisonDataTitle == null ? defaultDataTitle : uiProperties.comparisonDataTitle;
        return comparisonDataTitle;
    }
    get comparisonColor() {
        return this.uiProperties.comparisonColor;
    }
    get sortingByValue1() {
        return this.uiProperties.sortingByValue1;
    }
    set sortingByValue1(sortingByValue1) {
        if (sortingByValue1) {
            this.uiProperties.sortingByCategory1 = null;
            this.uiProperties.sortingByValue2 = null;
        }
        this.uiProperties.sortingByValue1 = sortingByValue1;
    }
    get sortingByCategory1() {
        if (this.sortingByValue1 || this.sortingByValue2) {
            return null;
        }
        return this.uiProperties.sortingByCategory1;
    }
    set sortingByCategory1(sortingByCategory1) {
        if (sortingByCategory1) {
            this.uiProperties.sortingByValue1 = null;
            this.uiProperties.sortingByValue2 = null;
        }
        this.uiProperties.sortingByCategory1 = sortingByCategory1;
    }
    get sortingByValue2() {
        if (this.sortingByValue1) {
            return null;
        }
        return this.uiProperties.sortingByValue2;
    }
    set sortingByValue2(sortingByValue2) {
        if (sortingByValue2) {
            this.uiProperties.sortingByCategory1 = null;
            this.uiProperties.sortingByValue1 = null;
        }
        this.uiProperties.sortingByValue2 = sortingByValue2;
    }
    get sortingByValue1Label() {
        return 'Sort by values 1';
    }
    get sortingByValue2Label() {
        return 'Sort by values 2';
    }
}

class UnitsUtil {
    static computeBiteUnit(value) {
        let unit = null;
        if (value > 1000000000.0) {
            unit = 'bln';
        }
        else if (value > 1000000.0) {
            unit = 'mln';
        }
        else if (value > 1000.0) {
            unit = 'k';
        }
        return unit;
    }
    static transform(value, decimals, unit) {
        let modifiedValue = UnitsUtil.computeValueBasedOnUnit(value, unit);
        if (decimals) {
            modifiedValue = Math.round(modifiedValue * Math.pow(10, decimals)) / Math.pow(10, decimals);
        }
        return modifiedValue + '';
    }
    static computeValueBasedOnUnit(value, unit) {
        if (unit) {
            let newValue = value;
            switch (unit) {
                case 'k':
                    newValue = newValue / 1000.0;
                    break;
                case 'mln':
                    newValue = newValue / 1000000.0;
                    break;
                case 'bln':
                    newValue = newValue / 1000000000.0;
                    break;
            }
            /* Keep only one decimal value  */
            // return Math.round(newValue * 10.0) / 10.0;
        }
        // if (value % 1 !== 0) {
        //   // number has decimals
        //   return Math.round(value * 10.0) / 10.0;
        // }
        return value;
    }
}

class KeyFigureBiteLogic extends BiteLogic {
    constructor(bite) {
        super(bite);
        this.bite = bite;
    }
    computeBiteUnit(forceRecompute) {
        if (forceRecompute || !this.computedProperties.unit) {
            this.computedProperties.unit = UnitsUtil.computeBiteUnit(this.dataProperties.value);
        }
    }
    populateWithHxlProxyInfo(hxlData, tagToTitleMap) {
        this.populateDataTitleWithHxlProxyInfo();
        const hxlTagIndex = this.findHxlTagIndex(this.bite.ingredient.valueColumn, hxlData);
        if (hxlTagIndex >= 0) {
            this.dataProperties.value = hxlData[2][hxlTagIndex];
            this.computeBiteUnit(false);
        }
        else {
            throw new Error(`${this.bite.ingredient.valueColumn} not found in hxl proxy response`);
        }
        return this;
    }
    initUIProperties() {
        return new KeyFigureUIProperties();
    }
    initComputedProperties() {
        return new KeyFigureComputedProperties();
    }
    initDataProperties() {
        return new KeyFigureDataProperties();
    }
    colorUsage() {
        return ColorUsage.NONE;
    }
    hasData() {
        return typeof this.dataProperties.value === 'number';
    }
    get dataProperties() {
        return this.bite.dataProperties;
    }
    get uiProperties() {
        return this.bite.uiProperties;
    }
    get computedProperties() {
        return this.bite.computedProperties;
    }
    get preText() {
        return this.uiProperties.preText;
    }
    get postText() {
        return this.uiProperties.postText;
    }
    get numberFormat() {
        return this.uiProperties.numberFormat;
    }
    get unit() {
        const defaultUnit = this.computedProperties.unit;
        return this.uiProperties.unit == null ? defaultUnit : this.uiProperties.unit;
    }
    get value() {
        return this.dataProperties.value;
    }
}

class TimeseriesChartBite extends ChartBite {
    static type() {
        return 'timeseries';
    }
    constructor(ingredient) {
        super(ingredient);
        this.displayCategory = 'Timeseries';
        this.uiProperties = new TimeseriesChartUIProperties();
    }
}
const DEFAULT_DATE_FORMAT = '%d %b %Y';
class TimeseriesChartUIProperties extends ChartUIProperties {
    constructor() {
        super();
        this.showPoints = false;
        this.showAllDates = false;
        this.dateFormat = DEFAULT_DATE_FORMAT;
    }
}

class TimeseriesChartBiteLogic extends ChartBiteLogic {
    static { this.REMOVE_EMPTY_VALUED_ROWS_FILTER = 'remove empty valued rows'; }
    initUIProperties() {
        return new TimeseriesChartUIProperties();
    }
    populateWithTitle(columnNames, hxlTags) {
        super.populateWithTitle(columnNames, hxlTags);
        const dateColumn = columnNames[this.tagToIndexMap[this.bite.ingredient.dateColumn]];
        this.bite.computedProperties.title += ` by ${dateColumn}`;
        return this;
    }
    populateDefaultFilters() {
        const filtersWith = [];
        this.valueColumns.forEach(valueCol => {
            filtersWith.push({ [valueCol]: 'is not empty' });
        });
        if (!this.computedProperties.explainedFiltersMap) {
            this.computedProperties.explainedFiltersMap = {};
        }
        this.computedProperties.explainedFiltersMap[TimeseriesChartBiteLogic.REMOVE_EMPTY_VALUED_ROWS_FILTER] =
            new BiteFilters(filtersWith, []);
        return this;
    }
    populateWithHxlProxyInfo(hxlData, tagToTitleMap) {
        super.populateDataTitleWithHxlProxyInfo();
        const valColIndex = this.findHxlTagIndex(this.bite.ingredient.valueColumn, hxlData);
        const dateColIndex = this.findHxlTagIndex(this.bite.ingredient.dateColumn, hxlData);
        if (this.bite.ingredient.aggregateColumn) {
            const aggColIndex = this.findHxlTagIndex(this.bite.ingredient.aggregateColumn, hxlData);
            this.multipleLinePopulateDataForChart(aggColIndex, hxlData, dateColIndex, valColIndex);
        }
        else {
            this.simplePopulateDataForChart(dateColIndex, valColIndex, hxlData);
        }
        return this;
    }
    buildImportantPropertiesList() {
        const importantProperties = super.buildImportantPropertiesList();
        importantProperties.push(this.bite.ingredient.dateColumn);
        return importantProperties;
    }
    multipleLinePopulateDataForChart(aggColIndex, hxlData, dateColIndex, valColIndex) {
        const foundGroups = this.findGroups(aggColIndex, hxlData);
        const values = [];
        const groupToIdxMap = {};
        foundGroups.forEach((group, idx) => {
            values.push([group]);
            groupToIdxMap[group] = idx;
        });
        const dates = ['Date'];
        let prevDate = null;
        for (let i = 2; i < hxlData.length; i++) {
            const date = hxlData[i][dateColIndex];
            if (date !== prevDate) {
                prevDate = date;
                dates.push(date);
                values.forEach(groupList => groupList.push(0));
            }
            const group = hxlData[i][aggColIndex];
            if (group && group.trim()) {
                const val = hxlData[i][valColIndex];
                const valueList = values[groupToIdxMap[group]];
                valueList[valueList.length - 1] = val;
            }
        }
        values.splice(0, 0, dates);
        this.dataProperties.values = values;
    }
    simplePopulateDataForChart(dateColIndex, valColIndex, hxlData) {
        if (dateColIndex >= 0 && valColIndex >= 0) {
            const values = [this.bite.computedProperties.dataTitle];
            const categories = ['Date'];
            for (let i = 2; i < hxlData.length; i++) {
                values.push(hxlData[i][valColIndex]);
                categories.push(hxlData[i][dateColIndex]);
            }
            this.dataProperties.values = [categories, values];
        }
        else {
            throw new Error(`${this.bite.ingredient.valueColumn} or ${this.bite.ingredient.aggregateColumn}`
                + 'not found in hxl proxy response');
        }
    }
    findGroups(aggColIndex, hxlData) {
        const mySet = new Set();
        for (let i = 2; i < hxlData.length; i++) {
            const group = hxlData[i][aggColIndex];
            if (group && group.trim()) {
                mySet.add(group.trim());
            }
        }
        const result = [];
        mySet.forEach(item => result.push(item));
        return result;
    }
    usesDateColumn() {
        // if (this.bite.ingredient.dateColumn) {
        //   return true;
        // }
        return true;
    }
    colorUsage() {
        if (this.bite.ingredient.aggregateColumn) {
            return ColorUsage.MANY;
        }
        return ColorUsage.ONE;
    }
    initColorsIfNeeded(colorPattern) {
        if (!this.uiProperties.internalColorPattern) {
            this.uiProperties.internalColorPattern = colorPattern;
        }
        if (!this.uiProperties.color) {
            this.uiProperties.color = colorPattern[1];
        }
    }
    hasData() {
        // values is an array of array
        // First sub-array represents the date points
        // each additional sub-array represent a timeseries/line in the chart
        if (this.values != null && this.values.length >= 2) {
            return true;
        }
        return false;
    }
    get uiProperties() {
        return this.bite.uiProperties;
    }
    get showPoints() {
        return this.uiProperties.showPoints;
    }
    set showPoints(showPoints) {
        this.uiProperties.showPoints = showPoints;
    }
    get showAllDates() {
        return this.uiProperties.showAllDates;
    }
    set showAllDates(showPoints) {
        this.uiProperties.showAllDates = showPoints;
    }
    get dateFormat() {
        return this.uiProperties.dateFormat || DEFAULT_DATE_FORMAT;
    }
    set dateFormat(showPoints) {
        this.uiProperties.dateFormat = showPoints;
    }
    get sortingByValue1Label() {
        return null;
    }
    get sortingByValue2Label() {
        return null;
    }
    get sortingByCategory1Label() {
        return null;
    }
}

class BiteLogicFactory {
    static createBiteLogic(bite) {
        if (bite) {
            switch (bite.type) {
                case KeyFigureBite.type():
                    return new KeyFigureBiteLogic(bite);
                case ChartBite.type():
                    return new ChartBiteLogic(bite);
                case TimeseriesChartBite.type():
                    return new TimeseriesChartBiteLogic(bite);
                case ComparisonChartBite.type():
                    return new ComparisonChartBiteLogic(bite);
                default:
                    return null;
            }
        }
        return null;
    }
}

class MyLogService {
    info(message) {
        console.log(message);
    }
    log(message) {
        console.log(message);
    }
    error(message) {
        console.error(message);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: MyLogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: MyLogService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: MyLogService, decorators: [{
            type: Injectable
        }] });

class NoDataBodyInHxlResponseError extends Error {
    constructor(message) {
        super(message);
        this.message = message;
        this.name = 'NoDataBodyInHxlResponseError';
    }
}
class HxlProxyResponseValidator {
    constructor(hxlData) {
        this.hxlData = hxlData;
    }
    ;
    check() {
        if (!this.hxlData) {
            throw new Error('No data returned by the HXL Proxy');
        }
        else if (!Array.isArray(this.hxlData)) {
            let message = 'There was a problem with the data returned from the HXL Proxy';
            if (this.hxlData.error) {
                message += ` - error: ${this.hxlData.error}`;
            }
            if (this.hxlData.message) {
                message += ` - message: ${this.hxlData.message}`;
            }
            throw new Error(message);
        }
        else if (this.hxlData.length < 2) {
            throw new Error('Only 1 row was returned from HXL Proxy. Not a complete header.');
        }
        else if (this.hxlData.length === 2) {
            const message = 'The data source doesn\'t contain the values needed for this visualization.';
            throw new NoDataBodyInHxlResponseError(message);
        }
        return true;
    }
}

class AbstractHxlTransformer {
    constructor(biteLogic) {
        this.biteLogic = biteLogic;
        if (biteLogic) {
            const bite = biteLogic.getBite();
            this.type = bite.type;
            this.valueTags = biteLogic.valueColumns;
            this.groupByTags = bite.ingredient.aggregateColumn ? [bite.ingredient.aggregateColumn] : [];
            this.aggregateFunction = bite.ingredient.aggregateFunction;
        }
    }
    generateJsonFromRecipes() {
        return JSON.stringify(this.buildRecipes());
    }
}

class BasicRecipe {
    constructor(filter) {
        this.filter = filter;
    }
}
class CountRecipe extends BasicRecipe {
    /**
     *
     * @param patterns column names to aggregate by
     * @param aggregators the operations and respective columns. ex: ["sum(#targeted) as Total targeted#targeted+total"]
     */
    constructor(patterns, aggregators) {
        super('count');
        this.patterns = patterns;
        this.aggregators = aggregators;
    }
}
class RenameRecipe extends BasicRecipe {
    /**
     *
     * @param specs string containing old and new tag (plus optional header) #old_tagspec:New header#new_tagspec
     */
    constructor(specs) {
        super('rename_columns');
        this.specs = specs;
    }
}
class CutRecipe extends BasicRecipe {
    /**
     *
     * @param whitelist Tag patterns for the columns to include
     */
    constructor(whitelist) {
        super('with_columns');
        this.whitelist = whitelist;
    }
}
class CleanRecipe extends BasicRecipe {
    /**
     *
     * @param date Tag that contains dates to clean
     */
    constructor(date) {
        super('clean_data');
        this.date = date;
    }
}
class SortRecipe extends BasicRecipe {
    /**
     *
     * @param tags comma separated tags by which to sort
     */
    constructor(tags, reverse) {
        super('sort');
        this.tags = tags;
        this.reverse = reverse;
    }
}
class WithoutRowsRecipe extends BasicRecipe {
    /**
     *
     * @param queries list of conditions like "date+year>2010"
     */
    constructor(queries) {
        super('without_rows');
        this.queries = queries;
    }
}
class WithRowsRecipe extends BasicRecipe {
    /**
     *
     * @param queries list of conditions like "date+year>2010"
     */
    constructor(queries) {
        super('with_rows');
        this.queries = queries;
    }
}
class AbstractOperation {
    constructor(_recipe) {
        this._recipe = _recipe;
    }
    get recipe() {
        return this._recipe;
    }
}
class CountOperation extends AbstractOperation {
    constructor(valueCols, aggCols, operation) {
        let aggColumns = [];
        if (aggCols && aggCols.length > 0) {
            aggColumns = aggCols.filter((value) => Boolean(value));
        }
        if (aggColumns.length === 0) {
            aggColumns.push('#fake_column');
        }
        const extraOperator = operation == "sum" ? "!" : "";
        const operations = valueCols.map(valueCol => `${operation}(${valueCol}${extraOperator}) as ${valueCol ? valueCol : '#meta+count'}`);
        super(new CountRecipe(aggColumns, operations));
    }
}
class RenameOperation extends AbstractOperation {
    constructor(oldTag, newTag, newHeader) {
        const myNewHeader = newHeader ? newHeader : '';
        super(new RenameRecipe(`${oldTag}:${myNewHeader}${newTag}`));
    }
}
class CutOperation extends AbstractOperation {
    constructor(valueCol, aggCols) {
        let keepList = [valueCol];
        if (aggCols) {
            keepList = keepList.concat(aggCols.filter((value) => Boolean(value)));
        }
        super(new CutRecipe(keepList));
    }
}
class CleanOperation extends AbstractOperation {
    constructor(dateCol) {
        super(new CleanRecipe(dateCol));
        if (dateCol && dateCol.length > 0) {
            this.recipe.date_format =
                Pattern.matchPatternToColumn('#date+year', dateCol) ? '%Y-01-01' : '%Y-%m-%d';
        }
    }
}
class SortOperation extends AbstractOperation {
    constructor(col, reverse) {
        reverse = reverse ? reverse : false;
        super(new SortRecipe(col, reverse));
    }
}
class FilterOperation extends AbstractOperation {
    /**
     * Filter operation (only based on one column for now)
     * @param filters list of filters from hxl recipe  (@see HxlFilter)
     * @param isWithFilter true if the records matching the filter should be kept, false otherwise
     * @param specialFilterValues dictionary with values for min, max, etc
     */
    constructor(filters, isWithFilter, specialFilterValues) {
        const filterConditions = [];
        filters.forEach(pair => {
            const column = Object.keys(pair)[0];
            let value = pair[column];
            const key = `${column}-${value}`;
            if (specialFilterValues && specialFilterValues[key]) {
                value = specialFilterValues[key];
            }
            if (['is empty', 'is not empty'].includes(value)) {
                filterConditions.push(`${column} ${value}`);
            }
            else {
                filterConditions.push(`${column}=${value}`);
            }
        });
        if (isWithFilter) {
            super(new WithRowsRecipe(filterConditions));
        }
        else {
            super(new WithoutRowsRecipe(filterConditions));
        }
    }
}

class CountChartTransformer extends AbstractHxlTransformer {
    // protected metaTagForAggColumn = '#meta+count';
    // protected nameForAggregatedValueColumn(): string {
    //   return '#count';
    // }
    buildRecipes() {
        const recipes = [];
        const countOperation = new CountOperation(this.valueTags, this.groupByTags, this.aggregateFunction);
        recipes.push(countOperation.recipe);
        if (this.groupByTags) {
            let dateTag = null;
            for (let i = 0; i < this.groupByTags.length; i++) {
                const tag = this.groupByTags[i];
                if (tag.indexOf('#date') >= 0) {
                    dateTag = tag;
                    break;
                }
            }
            if (dateTag) {
                const sortOperation = new SortOperation(dateTag, true);
                recipes.push(sortOperation.recipe);
            }
            else if (this.groupByTags.length > 0) {
                const sortOperation = new SortOperation(this.groupByTags[0], true);
                recipes.push(sortOperation.recipe);
            }
        }
        // let cutOperation = new CutOperation('#meta+sum', this.biteInfo.groupByTags);
        // recipes.push(cutOperation.recipe);
        // const renameOperation = new RenameOperation(this.metaTagForAggColumn, this.nameForAggregatedValueColumn(), null);
        // recipes.push(renameOperation.recipe);
        return recipes;
    }
}

class DistinctCountChartTransformer extends AbstractHxlTransformer {
    buildRecipes() {
        const recipes = [];
        const countOperation1 = new CountOperation([''], this.groupByTags.concat(this.valueTags), 'count');
        recipes.push(countOperation1.recipe);
        const countOperation2 = new CountOperation([''], this.groupByTags, 'count');
        recipes.push(countOperation2.recipe);
        const renameOperation = new RenameOperation('#meta+count', this.valueTags[0], null);
        recipes.push(renameOperation.recipe);
        return recipes;
    }
}

class FilterSettingTransformer extends AbstractHxlTransformer {
    constructor(innerTransformer, filters, specialFilterValues) {
        super(null);
        this.innerTransformer = innerTransformer;
        this.filters = filters;
        this.specialFilterValues = specialFilterValues;
    }
    buildRecipes() {
        let recipes = [];
        if (this.filters.filterWith) {
            /**
             * For filterWith we want AND filters. So we need to chain several FilterOperations together. One for each filter
             * in filterWith. A FilterOperation supports OR between the LIST of filters that is given as an argument.
             * So we need to transform the one filter to a list.
             */
            this.filters.filterWith.forEach(filter => {
                recipes.push(new FilterOperation([filter], true, this.specialFilterValues).recipe);
            });
        }
        if (this.filters.filterWithout && this.filters.filterWithout.length > 0) {
            recipes.push(new FilterOperation(this.filters.filterWithout, false, this.specialFilterValues).recipe);
        }
        const innerRecipes = this.innerTransformer.buildRecipes();
        recipes = recipes.concat(innerRecipes);
        return recipes;
    }
}

class TimeseriesChartTransformer extends AbstractHxlTransformer {
    constructor(innerTransformer, biteLogic) {
        super(null);
        this.innerTransformer = innerTransformer;
        this.dateTag = biteLogic.dateColumn;
        this.valueTags = biteLogic.valueColumns;
    }
    buildRecipes() {
        let recipes = [];
        const cleanOperation = new CleanOperation(this.dateTag);
        recipes.push(cleanOperation.recipe);
        const sortOperation = new SortOperation(this.dateTag);
        recipes.push(sortOperation.recipe);
        /* insert date as first grouping column */
        this.innerTransformer.groupByTags.splice(0, 0, this.dateTag);
        const innerRecipes = this.innerTransformer.buildRecipes();
        recipes = recipes.concat(innerRecipes);
        return recipes;
    }
}

class HxlproxyService {
    constructor(logger, httpClient) {
        this.logger = logger;
        this.httpClient = httpClient;
        this.config = {};
        this.specialFilterValues = {};
    }
    // constructor(private logger: Logger, private http: Http) {
    // let observable = this.getMetaRows('https://test-data.humdata.org/dataset/' +
    //   '8b154975-4871-4634-b540-f6c77972f538/resource/3630d818-344b-4bee-b5b0-6ddcfdc28fc8/download/eed.csv');
    // observable.subscribe( this.testResponse.bind(this) );
    // this.getDataForBite({type: 'chart', groupByTags: ['#adm1+name', '#adm1+code'], valueTag: '#affected+buildings+partially'});
    // }
    init(params) {
        for (const key in params) {
            if (params.hasOwnProperty(key)) {
                this.config[key] = params[key];
            }
        }
    }
    fetchMetaRows(hxlFileUrl) {
        this.hxlFileUrl = hxlFileUrl;
        let myObservable;
        if (this.metaRows && !this.config['noCachedMetarows']) {
            this.logger.log('Using cached metarows');
            const mySubject = new AsyncSubject();
            mySubject.next(this.metaRows);
            mySubject.complete();
            myObservable = mySubject;
        }
        else {
            myObservable = this.makeCallToHxlProxy([{ key: 'max-rows', value: '0' }], this.processMetaRowResponse);
        }
        return myObservable;
    }
    fetchFilterSpecialValues(filter) {
        const myObservable = new AsyncSubject();
        const inputs = [];
        const availableSpecialValues = {
            '$MAX$': 'max',
            '$MIN$': 'min'
        };
        const createHxlProxyRecipes = ((pair) => {
            const column = Object.keys(pair)[0];
            const value = pair[column];
            if (Object.keys(availableSpecialValues).indexOf(value) >= 0) {
                const key = `${column}-${value}`;
                const aggFunction = availableSpecialValues[value];
                // If we haven't yet found the special value for this column (ex: max for #date+year) then get it now
                if (!this.specialFilterValues[key]) {
                    const countRecipe = new CountRecipe(['#fakeColumn'], [`${aggFunction}(${column})`]);
                    inputs.push({
                        recipes: JSON.stringify([countRecipe]),
                        key: key
                    });
                }
            }
        });
        if (filter) {
            (filter.filterWith || []).forEach(createHxlProxyRecipes);
            (filter.filterWithout || []).forEach(createHxlProxyRecipes);
        }
        const hxlProxyObservables = inputs.map(input => {
            return this.makeCallToHxlProxy([{ key: 'recipe', value: input.recipes }], (response) => {
                const ret = response;
                // 2 header rows then comes the data, 1 fake column
                if (ret.length === 3 && ret[2].length > 1) {
                    const specialValue = ret[2][1];
                    this.specialFilterValues[input.key] = specialValue;
                    return true;
                }
                else {
                    console.error('Didn\'t get filter special value from hxl proxy');
                    return false;
                }
            });
        });
        forkJoin(hxlProxyObservables).subscribe(null, null, () => {
            myObservable.next(this.specialFilterValues);
            myObservable.complete();
        });
        return myObservable;
    }
    populateBite(bite, hxlFileUrl) {
        const biteLogic = BiteLogicFactory.createBiteLogic(bite);
        let transformer;
        switch (bite.ingredient.aggregateFunction) {
            case 'count':
            case 'average':
            case 'sum':
                transformer = new CountChartTransformer(biteLogic);
                break;
            case 'distinct-count':
                transformer = new DistinctCountChartTransformer(biteLogic);
                break;
        }
        if (biteLogic.usesDateColumn()) {
            transformer = new TimeseriesChartTransformer(transformer, biteLogic);
        }
        // if (bite.filteredValues && bite.filteredValues.length > 0) {
        //   transformer = new FilterSettingTransformer(transformer, bite.ingredient.valueColumn, bite.filteredValues);
        // }
        return this.fetchFilterSpecialValues(biteLogic.filters)
            .pipe(flatMap((specialFilterValues) => {
            if (biteLogic.hasFilters()) {
                transformer = new FilterSettingTransformer(transformer, biteLogic.filters, specialFilterValues);
            }
            const recipesStr = transformer.generateJsonFromRecipes();
            // this.logger.log(recipesStr);
            const responseToBiteMapping = (response) => {
                new HxlProxyResponseValidator(response).check();
                return biteLogic.populateWithHxlProxyInfo(response, this.tagToTitleMap).getBite();
            };
            const onErrorBiteProcessor = (customErrorMessage) => {
                biteLogic.getBite().errorMsg = customErrorMessage ?
                    customErrorMessage : 'Error while retrieving data values';
                return of(biteLogic.getBite());
            };
            return this.makeCallToHxlProxy([{ key: 'recipe', value: recipesStr }], responseToBiteMapping, onErrorBiteProcessor);
        }));
    }
    /**
     * Makes a call to the hxl proxy
     * @param params parameter pairs that will be sent to the HXL Proxy in the URL (the data src url should not be specified here)
     * @param mapFunction function that will map the result to some data structure
     * @param errorHandler error handling function
     */
    makeCallToHxlProxy(params, mapFunction, errorHandler) {
        // let myMapFunction: (response: Response) => T;
        // if (mapFunction) {
        //   myMapFunction = mapFunction;
        // } else {
        //   myMapFunction = (response: Response) => response.json();
        // }
        let url = `${this.config['hxlProxy']}?url=${encodeURIComponent(this.hxlFileUrl)}`;
        if (params) {
            for (let i = 0; i < params.length; i++) {
                url += '&' + params[i].key + '=' + encodeURIComponent(params[i].value);
            }
        }
        // this.logger.log('The call will be made to: ' + url);
        return this.httpClient.get(url).pipe(map(mapFunction.bind(this)), catchError(err => this.handleError(err, errorHandler)));
    }
    processMetaRowResponse(response) {
        const ret = response;
        // let ret = [json[0], json[1]];
        this.logger.log('Response is: ' + ret);
        this.metaRows = ret;
        this.tagToTitleMap = {};
        if (ret.length === 2) {
            for (let i = 0; i < ret[1].length; i++) {
                this.tagToTitleMap[ret[1][i]] = ret[0][i];
            }
        }
        else {
            throw new Error('There should be 2 meta rows');
        }
        return ret;
    }
    // private testResponse(result) {
    //   this.logger.log('Test response is: ' + result);
    // }
    handleError(error, errorHandler) {
        let errMsg;
        // TODO: Response logic might need refactoring after switching to HttpClient in Angular 6
        if (error instanceof Response) {
            try {
                const body = error.json() || '';
                const err = body.error || JSON.stringify(body);
                errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
            }
            catch (e) {
                errMsg = e.toString();
            }
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error('ERR! ' + errMsg);
        let customErrorMessage = null;
        if (error instanceof NoDataBodyInHxlResponseError) {
            customErrorMessage = error.message;
        }
        const retValue = errorHandler ? errorHandler(customErrorMessage) : throwError(errMsg);
        return retValue;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: HxlproxyService, deps: [{ token: MyLogService }, { token: i2.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: HxlproxyService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: HxlproxyService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: MyLogService }, { type: i2.HttpClient }] });

class CookBookService {
    // private cookBooks: string[];
    constructor(logger, hxlproxyService, httpClient) {
        this.logger = logger;
        this.hxlproxyService = hxlproxyService;
        this.httpClient = httpClient;
        this.config = {};
        // this.cookBooks = [
        //   // 'assets/bites-chart.json',
        //   // 'assets/bites-key-figure.json',
        //   'https://raw.githubusercontent.com/OCHA-DAP/hxl-recipes/1.0.0/cookbook-library.json',
        // ];
    }
    hxlMatcher(generalColumn, dataColumn) {
        if (dataColumn.indexOf('#') < 0) {
            dataColumn = '#' + dataColumn.trim();
        }
        return Pattern.matchPatternToColumn(generalColumn, dataColumn);
    }
    matchInSet(dataColumn, recipeColumns) {
        return recipeColumns.filter(column => this.hxlMatcher(column, dataColumn)).length !== 0;
    }
    findColsForComparisonChart(recipeColumns, dataColumns) {
        const comparisonBiteInfoList = [];
        recipeColumns.forEach(recipeCol => {
            // comp_sections should be something like: [1st_value_hxltag, comparison_operator, 2nd_value_hxltag]
            const comp_sections = recipeCol.split(' ');
            if (comp_sections.length === 3) {
                const info = new ComparisonBiteInfo(comp_sections[1]);
                dataColumns.forEach(dataCol => {
                    if (Pattern.matchPatternToColumn(comp_sections[0], dataCol)) {
                        info.valueCol = dataCol;
                    }
                    else if (Pattern.matchPatternToColumn(comp_sections[2], dataCol)) {
                        info.comparisonValueCol = dataCol;
                    }
                });
                if (info.isFilled()) {
                    comparisonBiteInfoList.push(info);
                }
            }
            else {
                this.logger.error(`${recipeCol} should have 3 parts`);
            }
        });
        return comparisonBiteInfoList;
    }
    allCookbookPatternsMatch(hxlPatterns, hxlColumns) {
        for (let i = 0; i < hxlPatterns.length; i++) {
            const pattern = hxlPatterns[i];
            let matches = false;
            for (let j = 0; j < hxlColumns.length; j++) {
                const col = hxlColumns[j];
                if (Pattern.matchPatternToColumn(pattern, col)) {
                    matches = true;
                    break;
                }
            }
            if (!matches) {
                return false;
            }
        }
        return true;
    }
    determineCorrectCookbook(cookbooks, hxlColumns, chosenCookbookName) {
        const checkByName = (cookbook) => cookbook.name === chosenCookbookName;
        const checkByPattern = (cookbook) => {
            const hxlPatterns = cookbook.columns || [];
            hxlColumns = hxlColumns || [];
            if (this.allCookbookPatternsMatch(hxlPatterns, hxlColumns)) {
                return true;
            }
            return false;
        };
        const check = chosenCookbookName ? checkByName : checkByPattern;
        if (cookbooks && cookbooks.length > 0) {
            let selectedCookbook = cookbooks[0];
            // Setting default cookbook for the case when none will match
            for (let idx = 0; idx < cookbooks.length; idx++) {
                if (cookbooks[idx].default) {
                    selectedCookbook = cookbooks[idx];
                    break;
                }
            }
            let i = 0;
            for (i = 0; i < cookbooks.length; i++) {
                const cookbook = cookbooks[i];
                if (check(cookbook)) {
                    selectedCookbook = cookbooks[i];
                    break;
                }
            }
            selectedCookbook.selected = true;
            return selectedCookbook;
        }
        throw new Error('Cookbooks list is empty. Something went wrong !');
    }
    determineAvailableBites(columnNames, hxlTags, biteConfigs) {
        const bites = new Observable(observer => {
            biteConfigs.forEach((biteConfig) => {
                const aggregateColumns = [];
                const recipeColumns = biteConfig.ingredients.valueColumns;
                const dateColumns = [];
                let aggregateFunctions = biteConfig.ingredients.aggregateFunctions;
                if (!aggregateFunctions || aggregateFunctions.length === 0) {
                    aggregateFunctions = ['sum'];
                }
                let avAggCols = [];
                if (biteConfig.ingredients.aggregateColumns) {
                    biteConfig.ingredients.aggregateColumns.forEach(col => {
                        if (!(biteConfig.type === 'timeseries' && this.hxlMatcher('#date', col))) {
                            aggregateColumns.push(col);
                        }
                    });
                    // filter the available hxlTags, and not the recipe general tags
                    avAggCols = hxlTags.filter(col => this.matchInSet(col, aggregateColumns));
                    // avAggCols = aggregateColumns.filter(col => this.matchInSet(col, hxlTags));
                }
                let avValCols = [];
                let comparisonBiteInfoList = [];
                if (recipeColumns) {
                    if (biteConfig.type === ComparisonChartBite.type()) {
                        // avValCols will be empty in this case
                        // We need to find data column pairs that match the recipe
                        comparisonBiteInfoList = this.findColsForComparisonChart(recipeColumns, hxlTags);
                    }
                    else {
                        // filter the available hxlTags, and not the recipe general tags
                        avValCols = hxlTags.filter(col => this.matchInSet(col, recipeColumns));
                    }
                }
                if (biteConfig.type === TimeseriesChartBite.type()) {
                    hxlTags.forEach(col => {
                        if (this.hxlMatcher('#date', col)) {
                            dateColumns.push(col);
                        }
                    });
                }
                this.logger.info(recipeColumns);
                const biteTitle = biteConfig.title;
                const biteDescription = biteConfig.description;
                const currentFilters = new BiteFilters(biteConfig.ingredients.filtersWith, biteConfig.ingredients.filtersWithout);
                switch (biteConfig.type) {
                    case TimeseriesChartBite.type():
                        dateColumns.forEach(dateColumn => {
                            aggregateFunctions.forEach(aggFunction => {
                                /* For count function we don't need value columns */
                                const modifiedValueColumns = aggFunction === 'count' ? ['#count'] : avValCols;
                                modifiedValueColumns.forEach(val => {
                                    const general_ingredient = new Ingredient(null, val, aggFunction, dateColumn, null, null, currentFilters, biteTitle, biteDescription);
                                    const simple_bite = new TimeseriesChartBite(general_ingredient);
                                    BiteLogicFactory.createBiteLogic(simple_bite)
                                        .populateHashCode()
                                        .populateDefaultFilters()
                                        .populateWithTitle(columnNames, hxlTags);
                                    observer.next(simple_bite);
                                    avAggCols.forEach(agg => {
                                        const ingredient = new Ingredient(agg, val, aggFunction, dateColumn, null, null, currentFilters, biteTitle, biteDescription);
                                        const multiple_data_bite = new TimeseriesChartBite(ingredient);
                                        BiteLogicFactory.createBiteLogic(multiple_data_bite)
                                            .populateHashCode()
                                            .populateDefaultFilters()
                                            .populateWithTitle(columnNames, hxlTags);
                                        observer.next(multiple_data_bite);
                                    });
                                });
                            });
                        });
                        break;
                    case ComparisonChartBite.type():
                        aggregateFunctions.forEach(aggFunction => {
                            // We add a fake empty column for generating total comparisons (NOR grouped by any col)
                            const avAggColsAndFake = avAggCols.length > 0 ? avAggCols : [''];
                            avAggColsAndFake.forEach((agg) => {
                                comparisonBiteInfoList.forEach(info => {
                                    const ingredient = new Ingredient(agg, info.valueCol, aggFunction, null, info.comparisonValueCol, info.operator, currentFilters, biteTitle, biteDescription);
                                    const bite = new ComparisonChartBite(ingredient);
                                    BiteLogicFactory.createBiteLogic(bite)
                                        .populateHashCode()
                                        .populateDefaultFilters()
                                        .populateWithTitle(columnNames, hxlTags);
                                    observer.next(bite);
                                });
                            });
                        });
                        break;
                    case ChartBite.type():
                        aggregateFunctions.forEach(aggFunction => {
                            avAggCols.forEach((agg) => {
                                /* For count function we don't need value columns */
                                const modifiedValueColumns = aggFunction === 'count' ? ['#count'] : avValCols;
                                modifiedValueColumns.forEach(val => {
                                    const ingredient = new Ingredient(agg, val, aggFunction, null, null, null, currentFilters, biteTitle, biteDescription);
                                    const bite = new ChartBite(ingredient, biteConfig.options);
                                    BiteLogicFactory.createBiteLogic(bite)
                                        .populateHashCode()
                                        .populateDefaultFilters()
                                        .populateWithTitle(columnNames, hxlTags);
                                    observer.next(bite);
                                });
                            });
                        });
                        break;
                    case KeyFigureBite.type():
                        aggregateFunctions.forEach(aggFunction => {
                            /* For count function we don't need value columns */
                            const modifiedValueColumns = aggFunction === 'count' ? ['#count'] : avValCols;
                            modifiedValueColumns.forEach(val => {
                                const ingredient = new Ingredient(null, val, aggFunction, null, null, null, currentFilters, biteTitle, biteDescription);
                                const bite = new KeyFigureBite(ingredient);
                                BiteLogicFactory.createBiteLogic(bite)
                                    .populateHashCode()
                                    .populateDefaultFilters()
                                    .populateWithTitle(columnNames, hxlTags);
                                observer.next(bite);
                            });
                        });
                        break;
                }
            });
            observer.complete();
        });
        return bites;
    }
    load(url, recipeUrl, chosenCookbookName) {
        const cookbookUrls = [recipeUrl];
        const cookBooksObs = cookbookUrls.map(book => this.httpClient.get(book)
            .pipe(catchError((err) => {
            let errorMessage = err.message;
            try {
                errorMessage += ' More details: ' + err.error.error.message;
            }
            catch (e) { }
            this.logger.error(errorMessage);
            return of({});
        })));
        const responseObs = cookBooksObs.reduce((prev, current, idx) => merge(prev, current));
        const toListOfCookbooks = (res) => {
            const configJson = res;
            let cookbooks;
            if (Array.isArray(configJson)) {
                const recipes = configJson;
                const cookbook = {
                    title: 'Untitled Cookbook',
                    recipes: recipes,
                    type: 'cookbook'
                };
                cookbooks = [cookbook];
            }
            else if (configJson.type && configJson.type === 'cookbook') {
                const cookbook = configJson;
                cookbooks = [cookbook];
            }
            else if (configJson.type && configJson.type === 'cookbook-library') {
                const cookbookLibrary = configJson;
                cookbooks = cookbookLibrary.cookbooks;
            }
            else {
                this.logger.error('List of cookbooks will be empty (because of a previous error). No bites will be generated');
                return [];
            }
            return cookbooks;
        };
        /**
         * Observable<Response> -> Observable<Cookbook[]> with several events for each json file loaded
         *    -> Observable<Cookbook>
         *    -> Observable<Cookbook[]> one event containing a list with all the cookbooks from all files
         */
        const cookbookListObs = responseObs.pipe(mergeMap(toListOfCookbooks), toArray());
        const metaRowsObs = this.hxlproxyService.fetchMetaRows(url);
        const cookbooksAndTagsObs = forkJoin(cookbookListObs, metaRowsObs).pipe(map(res => {
            const cookbooks = res[0];
            const rows = res[1];
            const columnNames = rows[0];
            const hxlTags = rows[1];
            const chosenCookbook = this.determineCorrectCookbook(cookbooks, hxlTags, chosenCookbookName);
            return {
                cookbooks: cookbooks,
                chosenCookbook: chosenCookbook,
                hxlTags: hxlTags,
                columnNames: columnNames,
            };
        }));
        cookbooksAndTagsObs.pipe(catchError(err => this.handleError(err)));
        /**
         * publishLast() - so that an observer subscribing later would receive the last notification again
         * refCount() - so that the first observer subscribing would trigger the start of the HTTP request
         *            ( otherwise a connect() would've been needed)
         */
        const publishedCookbooksAndTagsObs = cookbooksAndTagsObs
            .pipe(publishLast(), refCount());
        const bites = publishedCookbooksAndTagsObs
            .pipe(mergeMap((res) => {
            return this.determineAvailableBites(res.columnNames, res.hxlTags, res.chosenCookbook.recipes);
        }));
        const availableCookbooksObs = publishedCookbooksAndTagsObs.pipe(map((res) => res.cookbooks));
        return {
            biteObs: bites,
            cookbookAndTagsObs: publishedCookbooksAndTagsObs
        };
    }
    handleError(error) {
        let errMsg;
        // TODO: Response logic might need refactoring after switching to HttpClient in Angular 6
        if (error instanceof Response) {
            try {
                const body = error.json() || '';
                const err = body.error || JSON.stringify(body);
                errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
            }
            catch (e) {
                errMsg = e.toString();
            }
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error('ERR! ' + errMsg);
        const retValue = throwError(errMsg);
        return retValue;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: CookBookService, deps: [{ token: MyLogService }, { token: HxlproxyService }, { token: i2.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: CookBookService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: CookBookService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: MyLogService }, { type: HxlproxyService }, { type: i2.HttpClient }] });
class ComparisonBiteInfo {
    constructor(operator) {
        this.operator = operator;
    }
    isFilled() {
        if (this.valueCol && this.comparisonValueCol && this.operator) {
            return true;
        }
        return false;
    }
}

const GA_PAGEVIEW = 'pageview';
const GA_EVENT = 'event';
// export type GaExtras = {
//   'type'?: 'pageview' | 'event',
//   'label'?: string,
//   'action'?: string,
//   'category'?: string,
//   'value'?: number,
//   'dimensionInfo'?: MapOfStrings
// };
/**
 * Service that will try to abstract sending the analytics events
 * to Google Analytics and Mixpanel, but do nothing if the libs are
 * not loaded
 */
class AnalyticsService {
    constructor(logger) {
        this.logger = logger;
        this.gaInitialised = false;
        this.mpInitialised = false;
    }
    init(mpKey) {
        try {
            // this.gaToken = gaKey;
            if (dataLayer) {
                // ga('create', this.gaToken, 'auto');
                this.gaInitialised = true;
            }
        }
        catch (err) {
            this.logger.info('Can\'t initialize Google Analytics: ' + err);
        }
        try {
            this.mpToken = mpKey;
            if (this.mpToken) {
                mixpanel.init(this.mpToken);
                this.mpInitialised = true;
            }
        }
        catch (err) {
            this.logger.info('Can\'t initialize Mixpanel: ' + err);
        }
    }
    isInitialized() {
        return this.gaInitialised && this.mpInitialised;
    }
    // public trackView() {
    //   const category = 'hxl preview';
    //   const {url, pageTitle} = this.extractPageInfo();
    //   const gaData = {
    //     type: 'pageview',
    //     category: category,
    //     action: 'view',
    //     label: pageTitle || ''
    //   };
    //   const mpData = {
    //     category: category,
    //     metadata: {
    //       url: url,
    //       pageTitle: pageTitle,
    //     }
    //   };
    //   this.send(gaData, mpData);
    // }
    extractPageInfo() {
        let url;
        let pageTitle;
        try {
            url = (window.location !== window.parent.location)
                ? document.referrer
                : document.location.href;
            pageTitle = window.parent ? window.parent.document.title : window.document.title;
        }
        catch (Exception) {
            /* we don't have access to the parent due to cross-origin */
            url = document.referrer;
            pageTitle = window.document.title;
            this.logger.log(`in security error because of cross origin - url is ${url} and pageTitle is ${pageTitle}`);
        }
        return { url, pageTitle };
    }
    // public trackSave() {
    //   this.trackEventCategory('hxl preview edit');
    // }
    trackEventCategory(category, additionalGaData, additionalMpData) {
        const { url, pageTitle } = this.extractPageInfo();
        // additionalGaData = additionalGaData ? additionalGaData : {};
        // const gaData = {
        //   type: additionalGaData.type || GA_EVENT,
        //   category: additionalGaData.category || category,
        //   action: additionalGaData.action || null,
        //   label: additionalGaData.label || pageTitle || null,
        //   value: additionalGaData.value || null,
        //   dimensionInfo: additionalGaData.dimensionInfo
        // };
        const gaData = {
            'event': category + ' hdx',
        };
        if (additionalGaData) {
            Object.assign(gaData, additionalGaData);
        }
        const mpData = {
            category: category,
            metadata: {
                'embedded in': url,
                'page title': pageTitle,
            }
        };
        if (additionalMpData) {
            Object.assign(mpData.metadata, additionalMpData);
        }
        this.send(gaData, mpData);
    }
    send(gaData, mpData) {
        // this.logger.info('Logging the event...');
        let gaDimensionInfo = null;
        if (gaData.dimensionInfo) {
            gaDimensionInfo = gaData.dimensionInfo;
        }
        if (this.gaInitialised) {
            // this.logger.info('    Google Analytics - ok');
            if (GA_PAGEVIEW === gaData.type) {
                dataLayer.push({
                    'label': undefined,
                    'dataset_name': undefined,
                    'url': undefined,
                    'type': undefined,
                    'format': undefined,
                });
                dataLayer.push('pageview');
            }
            else {
                // ga('send', gaData.type, gaData.category, gaData.action, gaData.label, gaData.value, gaDimensionInfo);
                // const sendData = Object.assign({
                //   'hitType': gaData.type,
                //   'eventCategory': gaData.category,
                //   'eventAction': gaData.action,
                //   'eventLabel': gaData.label,
                //   'eventValue': gaData.value
                // }, gaDimensionInfo);
                // ga('send', sendData);
                dataLayer.push({
                    'label': undefined,
                    'dataset_name': undefined,
                    'url': undefined,
                    'type': undefined,
                    'format': undefined,
                });
                dataLayer.push(gaData);
            }
        }
        if (this.mpInitialised) {
            // this.logger.info('    Mixpanel         - ok');
            mixpanel.track(mpData.category, mpData.metadata);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: AnalyticsService, deps: [{ token: MyLogService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: AnalyticsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: AnalyticsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: MyLogService }] });

class HxlPreviewLibModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: HxlPreviewLibModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.1.5", ngImport: i0, type: HxlPreviewLibModule, declarations: [SimpleModalComponent], imports: [ModalModule], exports: [SimpleModalComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: HxlPreviewLibModule, providers: [HxlproxyService, CookBookService, AnalyticsService, MyLogService, provideHttpClient(withInterceptorsFromDi())], imports: [{
                ngModule: ModalModule,
                providers: [BsModalService, ComponentLoaderFactory, PositioningService]
            }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.5", ngImport: i0, type: HxlPreviewLibModule, decorators: [{
            type: NgModule,
            args: [{ declarations: [SimpleModalComponent],
                    exports: [
                        SimpleModalComponent
                    ], imports: [{
                            ngModule: ModalModule,
                            providers: [BsModalService, ComponentLoaderFactory, PositioningService]
                        }], providers: [HxlproxyService, CookBookService, AnalyticsService, MyLogService, provideHttpClient(withInterceptorsFromDi())] }]
        }] });

/*
 * Public API Surface of hxl-preview-ng-lib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AnalyticsService, Bite, BiteLogic, BiteLogicFactory, ChartBite, ChartBiteLogic, ChartComputedProperties, ChartDataProperties, ChartUIProperties, ColorUsage, ComparisonChartBite, ComparisonChartBiteLogic, ComparisonChartComputedProperties, ComparisonChartDataProperties, ComparisonChartUIProperties, ComputedProperties, CookBookService, DEFAULT_DATE_FORMAT, DataProperties, GA_EVENT, GA_PAGEVIEW, HxlPreviewLibModule, HxlproxyService, KeyFigureBite, KeyFigureBiteLogic, KeyFigureComputedProperties, KeyFigureDataProperties, KeyFigureUIProperties, MAX_LIMIT_VALUE, Pattern, SimpleModalComponent, TimeseriesChartBite, TimeseriesChartBiteLogic, TimeseriesChartUIProperties, UIProperties, UnitsUtil };
//# sourceMappingURL=hxl-preview-ng-lib.mjs.map
