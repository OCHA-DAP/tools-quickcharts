import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SimpleModalComponent implements OnInit {
    title: string;
    private staticModal;
    constructor();
    ngOnInit(): void;
    show(): void;
    hide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SimpleModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SimpleModalComponent, "hxl-simple-modal", never, { "title": { "alias": "title"; "required": false; }; }, {}, never, ["*"], false, never>;
}
