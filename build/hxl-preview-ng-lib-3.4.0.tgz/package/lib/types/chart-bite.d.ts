import { Bite, UIProperties, ComputedProperties, DataProperties } from './bite';
import { Ingredient } from './ingredient';
import { RecipeOptions } from './ingredients';
export declare class ChartBite extends Bite {
    static colorPattern: string[];
    static SORT_DESC: string;
    static SORT_ASC: string;
    static type(): string;
    constructor(ingredient: Ingredient, recipeOptions?: RecipeOptions);
}
export declare class ChartUIProperties extends UIProperties {
    swapAxis: boolean;
    showGrid: boolean;
    color: string;
    sortingByValue1: string;
    sortingByCategory1: string;
    limit: number;
}
export declare class ChartComputedProperties extends ComputedProperties {
    pieChart: boolean;
}
export declare class ChartDataProperties extends DataProperties {
    values: any[];
    categories: string[];
}
