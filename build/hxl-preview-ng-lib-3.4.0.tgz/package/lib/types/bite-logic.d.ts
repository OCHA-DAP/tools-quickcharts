import { BiteFilters } from './ingredient';
import { Bite, UIProperties, ComputedProperties, DataProperties } from './bite';
import { RecipeOptions } from './ingredients';
export declare abstract class BiteLogic {
    protected bite: Bite;
    protected tagToIndexMap: {
        [s: string]: number;
    };
    constructor(bite: Bite);
    abstract initUIProperties(): UIProperties;
    abstract initComputedProperties(): ComputedProperties;
    abstract initDataProperties(): DataProperties;
    /**
     * Generally used before saving the bite. We don't want the values to be saved as well.
     * The bites should have fresh data loaded from the data source each time.
     *
     */
    unpopulateBite(): BiteLogic;
    resetBite(): BiteLogic;
    protected populateDataTitleWithHxlProxyInfo(): BiteLogic;
    protected findHxlTagIndex(hxlTag: string, hxlData: any[][]): number;
    getBite(): Bite;
    populateHashCode(): BiteLogic;
    protected buildImportantPropertiesList(): string[];
    protected strHash(theString: string, startHash?: number): number;
    protected strListHash(strList: string[]): number;
    populateWithTitle(columnNames: string[], hxlTags: string[]): BiteLogic;
    populateDefaultFilters(): BiteLogic;
    hasFilters(): boolean;
    usesDateColumn(): boolean;
    initColorsIfNeeded(internalColorPattern: string[]): void;
    findComputedFilters(): BiteFilters;
    get sortingByValue1Label(): string;
    get sortingByValue2Label(): string;
    get sortingByCategory1Label(): string;
    get dataProperties(): DataProperties;
    get uiProperties(): UIProperties;
    get recipeOptions(): RecipeOptions;
    get computedProperties(): ComputedProperties;
    get dateColumn(): string;
    get valueColumns(): string[];
    get title(): string;
    get description(): string;
    get descriptionLength(): number;
    get dataTitle(): string;
    get internalColorPattern(): string[];
    get tempShowSaveCancelButtons(): boolean;
    set tempShowSaveCancelButtons(tempShowSaveCancelButtons: boolean);
    get filters(): BiteFilters;
    abstract populateWithHxlProxyInfo(hxlData: any[][], tagToTitleMap: any): BiteLogic;
    abstract colorUsage(): ColorUsage;
    abstract hasData(): boolean;
}
export declare enum ColorUsage {
    NONE = 0,
    ONE = 1,
    MANY = 2
}
