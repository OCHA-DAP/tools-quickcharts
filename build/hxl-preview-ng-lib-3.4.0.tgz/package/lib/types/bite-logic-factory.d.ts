import { Bite } from './bite';
import { BiteLogic } from './bite-logic';
export declare class BiteLogicFactory {
    static createBiteLogic(bite: Bite): BiteLogic;
}
