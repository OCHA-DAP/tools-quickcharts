import { AggregateFunctionOptions, HxlFilter } from './ingredients';
export declare class Ingredient {
    aggregateColumn: string;
    valueColumn: string;
    aggregateFunction: AggregateFunctionOptions;
    dateColumn?: string;
    comparisonValueColumn?: string;
    comparisonOperator?: string;
    filters?: BiteFilters;
    title?: string;
    description?: string;
    constructor(aggregateColumn: string, valueColumn: string, aggregateFunction: AggregateFunctionOptions, dateColumn?: string, comparisonValueColumn?: string, comparisonOperator?: string, filters?: BiteFilters, title?: string, description?: string);
}
export declare class BiteFilters {
    filterWith: HxlFilter[];
    filterWithout: HxlFilter[];
    constructor(filterWith: HxlFilter[], filterWithout: HxlFilter[]);
    static mergeBiteFilters(biteFilters1: BiteFilters, biteFilters2: BiteFilters): BiteFilters;
}
