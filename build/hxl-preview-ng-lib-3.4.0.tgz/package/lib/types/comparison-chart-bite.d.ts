import { Ingredient } from './ingredient';
import { ChartBite, ChartComputedProperties, ChartDataProperties, ChartUIProperties } from './chart-bite';
export declare class ComparisonChartBite extends ChartBite {
    static type(): string;
    constructor(ingredient: Ingredient);
}
export declare class ComparisonChartDataProperties extends ChartDataProperties {
    comparisonValues: any[];
}
export declare class ComparisonChartComputedProperties extends ChartComputedProperties {
    comparisonDataTitle: string;
}
export declare class ComparisonChartUIProperties extends ChartUIProperties {
    stackChart: boolean;
    comparisonDataTitle: string;
    comparisonColor: string;
    sortingByValue2: string;
    constructor();
}
