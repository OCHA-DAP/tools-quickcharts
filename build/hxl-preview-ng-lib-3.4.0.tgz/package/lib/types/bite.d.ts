import { RecipeOptions } from './ingredients';
import { Ingredient, BiteFilters } from './ingredient';
export declare abstract class Bite {
    errorMsg: string;
    ingredient: Ingredient;
    recipeOptions: RecipeOptions;
    computedProperties: ComputedProperties;
    uiProperties: UIProperties;
    dataProperties: DataProperties;
    type: string;
    hashCode: number;
    displayCategory: string;
    tempShowSaveCancelButtons: boolean;
    static type(): string;
    constructor(ingredient: Ingredient, recipeOptions?: RecipeOptions);
}
export declare class ComputedProperties {
    title: string;
    dataTitle: string;
    explainedFiltersMap: {
        [s: string]: BiteFilters;
    };
}
export declare class UIProperties {
    title: string;
    description: string;
    dataTitle: string;
    numberDecimals: number;
    internalColorPattern: string[];
}
/**
 * Data coming from the hxl proxy (processed maybe for showing in the charts)
 */
export declare class DataProperties {
}
