import { ChartBite, ChartUIProperties } from './chart-bite';
import { Ingredient } from './ingredient';
export declare class TimeseriesChartBite extends ChartBite {
    static type(): string;
    constructor(ingredient: Ingredient);
}
export declare const DEFAULT_DATE_FORMAT = "%d %b %Y";
export declare class TimeseriesChartUIProperties extends ChartUIProperties {
    showPoints: boolean;
    showAllDates: boolean;
    dateFormat: string;
    constructor();
}
