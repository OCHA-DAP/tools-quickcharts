import { TimeseriesChartUIProperties } from './timeseries-chart-bite';
import { ColorUsage } from './bite-logic';
import { ChartBiteLogic } from './chart-bite-logic';
export declare class TimeseriesChartBiteLogic extends ChartBiteLogic {
    static REMOVE_EMPTY_VALUED_ROWS_FILTER: string;
    initUIProperties(): TimeseriesChartUIProperties;
    populateWithTitle(columnNames: string[], hxlTags: string[]): TimeseriesChartBiteLogic;
    populateDefaultFilters(): TimeseriesChartBiteLogic;
    populateWithHxlProxyInfo(hxlData: any[][], tagToTitleMap: any): ChartBiteLogic;
    protected buildImportantPropertiesList(): string[];
    private multipleLinePopulateDataForChart;
    private simplePopulateDataForChart;
    private findGroups;
    usesDateColumn(): boolean;
    colorUsage(): ColorUsage;
    initColorsIfNeeded(colorPattern: string[]): void;
    hasData(): boolean;
    get uiProperties(): TimeseriesChartUIProperties;
    get showPoints(): boolean;
    set showPoints(showPoints: boolean);
    get showAllDates(): boolean;
    set showAllDates(showPoints: boolean);
    get dateFormat(): string;
    set dateFormat(showPoints: string);
    get sortingByValue1Label(): string;
    get sortingByValue2Label(): string;
    get sortingByCategory1Label(): string;
}
