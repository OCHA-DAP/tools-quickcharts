import { Bite, UIProperties, ComputedProperties, DataProperties } from './bite';
import { Ingredient } from './ingredient';
export declare class KeyFigureBite extends Bite {
    static type(): string;
    constructor(ingredient: Ingredient);
}
export declare class KeyFigureUIProperties extends UIProperties {
    unit: string;
    /**
     * User properties
     */
    preText: string;
    postText: string;
    numberFormat: string;
}
export declare class KeyFigureComputedProperties extends ComputedProperties {
    unit: string;
}
export declare class KeyFigureDataProperties extends DataProperties {
    value: number;
}
