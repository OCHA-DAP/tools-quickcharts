import { BiteLogic, ColorUsage } from './bite-logic';
import { KeyFigureBite, KeyFigureDataProperties, KeyFigureUIProperties, KeyFigureComputedProperties } from './key-figure-bite';
export declare class KeyFigureBiteLogic extends BiteLogic {
    protected bite: KeyFigureBite;
    constructor(bite: KeyFigureBite);
    computeBiteUnit(forceRecompute: boolean): void;
    populateWithHxlProxyInfo(hxlData: any[][], tagToTitleMap: any): KeyFigureBiteLogic;
    initUIProperties(): KeyFigureUIProperties;
    initComputedProperties(): KeyFigureComputedProperties;
    initDataProperties(): KeyFigureDataProperties;
    colorUsage(): ColorUsage;
    hasData(): boolean;
    get dataProperties(): KeyFigureDataProperties;
    get uiProperties(): KeyFigureUIProperties;
    get computedProperties(): KeyFigureComputedProperties;
    get preText(): string;
    get postText(): string;
    get numberFormat(): string;
    get unit(): string;
    get value(): number;
}
