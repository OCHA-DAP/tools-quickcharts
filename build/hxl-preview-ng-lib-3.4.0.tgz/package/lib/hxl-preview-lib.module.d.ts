import * as i0 from "@angular/core";
import * as i1 from "./component/simple-modal.component";
import * as i2 from "ngx-bootstrap/modal";
export declare class HxlPreviewLibModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HxlPreviewLibModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HxlPreviewLibModule, [typeof i1.SimpleModalComponent], [typeof i2.ModalModule], [typeof i1.SimpleModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HxlPreviewLibModule>;
}
