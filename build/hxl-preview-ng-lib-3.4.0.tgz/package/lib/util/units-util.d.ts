export declare class UnitsUtil {
    static computeBiteUnit(value: number): string;
    static transform(value: number, decimals: number, unit: string): string;
    private static computeValueBasedOnUnit;
}
