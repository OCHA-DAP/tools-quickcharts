/**
 * Mostly based on https://github.com/HXLStandard/libhxl-js/blob/master/hxl.js
 */
export declare class Pattern {
    private static existingPatternMap;
    private static matchingResultsMap;
    private includeAttributes;
    private excludeAttributes;
    private tag;
    static matchPatternToColumn(hxlPattern: string, hxlColumn: string): boolean;
    private static parse;
    /**
     * Based on https://github.com/HXLStandard/libhxl-js/blob/master/hxl.js hxl.classes.Pattern.parse()
     * @param hxlPattern
     */
    private constructor();
    private matchAttributes;
    private matchHxlColumn;
}
