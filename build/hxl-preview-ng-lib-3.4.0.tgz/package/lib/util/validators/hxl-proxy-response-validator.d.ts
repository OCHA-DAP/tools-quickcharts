export declare class NoDataBodyInHxlResponseError extends Error {
    message: string;
    constructor(message: string);
}
export declare class HxlProxyResponseValidator {
    hxlData: any;
    constructor(hxlData: any);
    check(): boolean;
}
