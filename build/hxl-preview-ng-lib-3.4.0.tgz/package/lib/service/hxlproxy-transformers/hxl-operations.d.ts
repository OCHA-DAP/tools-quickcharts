import { HxlFilter } from '../../types/ingredients';
export interface SpecialFilterValues {
    [s: string]: string;
}
export declare abstract class BasicRecipe {
    filter: string;
    constructor(filter: string);
}
export declare class CountRecipe extends BasicRecipe {
    patterns: string[];
    aggregators: string[];
    /**
     *
     * @param patterns column names to aggregate by
     * @param aggregators the operations and respective columns. ex: ["sum(#targeted) as Total targeted#targeted+total"]
     */
    constructor(patterns: string[], aggregators: string[]);
}
export declare abstract class AbstractOperation {
    protected readonly _recipe: BasicRecipe;
    constructor(_recipe: BasicRecipe);
    get recipe(): BasicRecipe;
}
export declare class CountOperation extends AbstractOperation {
    constructor(valueCols: string[], aggCols: string[], operation: string);
}
export declare class RenameOperation extends AbstractOperation {
    constructor(oldTag: string, newTag: string, newHeader: string);
}
export declare class CutOperation extends AbstractOperation {
    constructor(valueCol: string, aggCols: string[]);
}
export declare class CleanOperation extends AbstractOperation {
    constructor(dateCol: string);
}
export declare class SortOperation extends AbstractOperation {
    constructor(col: string, reverse?: boolean);
}
export declare class FilterOperation extends AbstractOperation {
    /**
     * Filter operation (only based on one column for now)
     * @param filters list of filters from hxl recipe  (@see HxlFilter)
     * @param isWithFilter true if the records matching the filter should be kept, false otherwise
     * @param specialFilterValues dictionary with values for min, max, etc
     */
    constructor(filters: HxlFilter[], isWithFilter: boolean, specialFilterValues?: SpecialFilterValues);
}
