import { BiteLogic } from '../../types/bite-logic';
import { BasicRecipe } from './hxl-operations';
export declare abstract class AbstractHxlTransformer {
    private biteLogic;
    protected type: string;
    protected valueTags: string[];
    groupByTags: string[];
    protected aggregateFunction: string;
    constructor(biteLogic: BiteLogic);
    abstract buildRecipes(): BasicRecipe[];
    generateJsonFromRecipes(): string;
}
