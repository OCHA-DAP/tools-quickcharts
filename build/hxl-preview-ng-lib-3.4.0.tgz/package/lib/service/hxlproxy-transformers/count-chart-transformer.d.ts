import { AbstractHxlTransformer } from './abstract-hxl-transformer';
import { BasicRecipe } from './hxl-operations';
export declare class CountChartTransformer extends AbstractHxlTransformer {
    buildRecipes(): BasicRecipe[];
}
