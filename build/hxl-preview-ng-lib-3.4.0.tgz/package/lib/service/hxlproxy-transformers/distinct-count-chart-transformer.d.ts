import { AbstractHxlTransformer } from './abstract-hxl-transformer';
import { BasicRecipe } from './hxl-operations';
export declare class DistinctCountChartTransformer extends AbstractHxlTransformer {
    buildRecipes(): BasicRecipe[];
}
