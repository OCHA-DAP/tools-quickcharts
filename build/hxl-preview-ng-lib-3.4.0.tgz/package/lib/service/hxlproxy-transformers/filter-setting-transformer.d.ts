import { BiteFilters } from '../../types/ingredient';
import { AbstractHxlTransformer } from './abstract-hxl-transformer';
import { BasicRecipe, SpecialFilterValues } from './hxl-operations';
export declare class FilterSettingTransformer extends AbstractHxlTransformer {
    private innerTransformer;
    private filters;
    private specialFilterValues;
    constructor(innerTransformer: AbstractHxlTransformer, filters: BiteFilters, specialFilterValues: SpecialFilterValues);
    buildRecipes(): BasicRecipe[];
}
