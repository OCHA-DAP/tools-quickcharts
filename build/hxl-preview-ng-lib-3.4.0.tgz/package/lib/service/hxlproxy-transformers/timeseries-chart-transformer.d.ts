import { AbstractHxlTransformer } from './abstract-hxl-transformer';
import { BasicRecipe } from './hxl-operations';
import { BiteLogic } from '../../types/bite-logic';
export declare class TimeseriesChartTransformer extends AbstractHxlTransformer {
    private innerTransformer;
    protected dateTag: string;
    constructor(innerTransformer: AbstractHxlTransformer, biteLogic: BiteLogic);
    buildRecipes(): BasicRecipe[];
}
