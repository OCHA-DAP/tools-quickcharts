import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Bite } from '../types/bite';
import { MyLogService } from './mylog.service';
import * as i0 from "@angular/core";
export declare class HxlproxyService {
    private logger;
    private httpClient;
    private config;
    private tagToTitleMap;
    private metaRows;
    private hxlFileUrl;
    private specialFilterValues;
    constructor(logger: MyLogService, httpClient: HttpClient);
    init(params: {
        [s: string]: any;
    }): void;
    fetchMetaRows(hxlFileUrl: string): Observable<string[][]>;
    private fetchFilterSpecialValues;
    populateBite(bite: Bite, hxlFileUrl: string): Observable<any>;
    /**
     * Makes a call to the hxl proxy
     * @param params parameter pairs that will be sent to the HXL Proxy in the URL (the data src url should not be specified here)
     * @param mapFunction function that will map the result to some data structure
     * @param errorHandler error handling function
     */
    private makeCallToHxlProxy;
    private processMetaRowResponse;
    private handleError;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxlproxyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HxlproxyService>;
}
