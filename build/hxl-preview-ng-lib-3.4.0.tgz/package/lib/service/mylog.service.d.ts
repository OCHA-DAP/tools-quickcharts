import * as i0 from "@angular/core";
export declare class MyLogService {
    info(message: any): void;
    log(message: any): void;
    error(message: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyLogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MyLogService>;
}
