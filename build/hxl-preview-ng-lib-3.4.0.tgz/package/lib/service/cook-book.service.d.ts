import { Observable } from 'rxjs';
import { Cookbook, BiteConfig } from '../types/bite-config';
import { HxlproxyService } from './hxlproxy.service';
import { Bite } from '../types/bite';
import { MyLogService } from './mylog.service';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
export declare class CookBookService {
    private logger;
    private hxlproxyService;
    private httpClient;
    private config;
    constructor(logger: MyLogService, hxlproxyService: HxlproxyService, httpClient: HttpClient);
    private hxlMatcher;
    private matchInSet;
    private findColsForComparisonChart;
    private allCookbookPatternsMatch;
    private determineCorrectCookbook;
    determineAvailableBites(columnNames: Array<string>, hxlTags: Array<string>, biteConfigs: Array<BiteConfig>): Observable<Bite>;
    load(url: string, recipeUrl: string, chosenCookbookName?: string): {
        biteObs: Observable<Bite>;
        cookbookAndTagsObs: Observable<CookbooksAndTags>;
    };
    private handleError;
    static ɵfac: i0.ɵɵFactoryDeclaration<CookBookService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CookBookService>;
}
export interface CookbooksAndTags {
    cookbooks: Cookbook[];
    chosenCookbook: Cookbook;
    hxlTags: string[];
    columnNames: string[];
}
