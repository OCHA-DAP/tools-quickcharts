import { MyLogService } from './mylog.service';
import * as i0 from "@angular/core";
export declare const GA_PAGEVIEW = "pageview";
export declare const GA_EVENT = "event";
export type MapOfStrings = {
    [s: string]: string | boolean | number | string[];
};
/**
 * Service that will try to abstract sending the analytics events
 * to Google Analytics and Mixpanel, but do nothing if the libs are
 * not loaded
 */
export declare class AnalyticsService {
    private logger;
    private gaInitialised;
    private mpInitialised;
    mpToken: string;
    constructor(logger: MyLogService);
    init(mpKey: string): void;
    isInitialized(): boolean;
    private extractPageInfo;
    trackEventCategory(category: string, additionalGaData?: MapOfStrings, additionalMpData?: MapOfStrings): void;
    private send;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnalyticsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnalyticsService>;
}
